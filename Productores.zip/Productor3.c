#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <sys/stat.h>

int main() {
    int N,a;
    srand(time(NULL));
    for(a=1;a<=20;a++) {
        N=rand() % 451 *2 + 100;   
        printf("%d.- %d \n",a,(N+1));
    }
}
