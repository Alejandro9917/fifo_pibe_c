#include <unistd.h>
#include <fcntl.h>
#include<stdlib.h>
#include<time.h>
#include<stdio.h>
#include <sys/stat.h>

int main(int c, char** s){
    int i,N;
    srand(time(NULL));
    for(i = 1; i <= 20; i++){
	N=rand() % (('z' - 'a') + 1);	
        printf("%d.- '%c' \n", i,'a' + N);
    }
    return 0;
}
